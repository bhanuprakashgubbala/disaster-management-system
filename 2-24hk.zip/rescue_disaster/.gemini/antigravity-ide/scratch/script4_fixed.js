
        /**
         * ZERONET TACTICAL OS PRO - CORE APPLICATION LOGIC
         */
        const generateID = (prefix) => `${prefix}-${Math.floor(1000 + Math.random() * 9000)}`;
        const getTimestamp = () => new Date().toISOString().split('T')[1].slice(0, -1);

        // Digital Clock
        setInterval(() => {
            const clockEl = document.getElementById('digital-clock');
            if (clockEl) {
                const now = new Date();
                clockEl.innerText = now.toTimeString().split(' ')[0] + ' UTC';
            }
        }, 1000);

        // Theme Switcher Helper
        function setTheme(themeName) {
            document.documentElement.setAttribute('data-theme', themeName);
            document.querySelectorAll('.theme-dot').forEach(dot => dot.classList.remove('active'));
            const targetDot = document.querySelector(`.theme-dot[onclick*="${themeName}"]`);
            if (targetDot) targetDot.classList.add('active');
        }

        // Quick Auth Fill Helper
        function quickFillAuth(u, p) {
            document.getElementById('auth-user').value = u;
            document.getElementById('auth-pass').value = p;
            document.getElementById('btn-login').click();
        }

        // Export Ledger to CSV
        function exportLedgerCSV() {
            if (!window.zeronetApp || !window.zeronetApp.db || window.zeronetApp.db.records.length === 0) {
                alert("No casualty records to export yet.");
                return;
            }
            const records = window.zeronetApp.db.records;
            let csv = "Victim ID,Triage Priority,Symptoms,Latitude,Longitude,Relay Node\n";
            records.forEach(r => {
                csv += `"${r.id}","${r.triage}","${(r.symptoms || '').replace(/"/g, '""')}","${r.lat}","${r.lng}","${r.relayNode}"\n`;
            });
            const blob = new Blob([csv], { type: 'text/csv' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.setAttribute('href', url);
            a.setAttribute('download', `zeronet_casualty_ledger_${Date.now()}.csv`);
            a.click();
        }

        // --- 0. AUTHENTICATION GATEWAY ---
        class AuthManager {
            constructor(appInstance) {
                this.app = appInstance;
                this.currentUser = null;
                this.role = null;

                document.getElementById('btn-login').addEventListener('click', () => this.attemptLogin());
                document.getElementById('btn-logout').addEventListener('click', () => this.logout());

                // Allow pressing enter key in password field to submit
                document.getElementById('auth-pass').addEventListener('keypress', (e) => {
                    if (e.key === 'Enter') this.attemptLogin();
                });
            }

            attemptLogin() {
                const u = document.getElementById('auth-user').value.toLowerCase().trim();
                const p = document.getElementById('auth-pass').value.trim();
                const errBox = document.getElementById('auth-error');

                if (u === 'admin' && p === 'admin') {
                    this.role = 'ADMIN';
                } else if (u === 'user' && p === 'user') {
                    this.role = 'USER';
                } else {
                    errBox.classList.remove('hidden');
                    return;
                }

                this.currentUser = u;
                errBox.classList.add('hidden');
                this.transitionToApp();
            }

            transitionToApp() {
                document.getElementById('auth-screen').style.display = 'none';

                const appGrid = document.getElementById('main-app');
                appGrid.style.display = 'grid';
                appGrid.classList.remove('admin-layout', 'user-layout');

                if (this.role === 'ADMIN') {
                    appGrid.classList.add('admin-layout');
                    setTheme('amber');

                    document.getElementById('header-role').innerText = 'COMMAND CENTER (ADMIN)';
                    document.getElementById('header-role').className = 'text-amber-400 font-bold';
                    document.querySelectorAll('.role-admin').forEach(btn => btn.classList.remove('hidden-role'));
                    document.getElementById('ledger-title').innerText = "GLOBAL CASUALTY LEDGER";
                    document.getElementById('ledger-mod-title').innerText = "MODULE 04: GLOBAL TACTICAL LEDGER";

                    this.app.initAdminTools();
                    this.app.ui.clickTab('workspace-map');

                } else if (this.role === 'USER') {
                    appGrid.classList.add('user-layout');
                    setTheme('azure');

                    document.getElementById('header-role').innerText = 'FIELD RESPONDER (USER)';
                    document.getElementById('header-role').className = 'text-sky-400 font-bold';
                    document.querySelectorAll('.role-user').forEach(btn => btn.classList.remove('hidden-role'));
                    document.getElementById('ledger-title').innerText = "LOCAL CASUALTY LEDGER";
                    document.getElementById('ledger-mod-title').innerText = "MODULE 04: LOCAL PATIENT LEDGER";

                    this.app.initAdminTools(); // Initialize map for User as well
                    this.app.ui.clickTab('workspace-intake');
                }

                document.getElementById('sidebar-username').innerText = this.currentUser.toUpperCase();
                this.app.ui.logTerminal('AUTH', `Secure cryptographic link verified for operator ${this.currentUser} [${this.role}]`);

                // Broadcast live operator presence across the global mesh
                if (this.app.serverNet) {
                    this.app.serverNet.broadcastPresence();
                }
            }

            logout() {
                if (this.app.serverNet) {
                    this.app.serverNet.sendMeshEnvelope('disconnect', { nodeId: this.app.serverNet.deviceId, role: this.role });
                }
                this.currentUser = null;
                this.role = null;
                document.getElementById('auth-user').value = '';
                document.getElementById('auth-pass').value = '';

                setTheme('azure');
                document.getElementById('auth-screen').style.display = 'flex';
                document.getElementById('main-app').style.display = 'none';
            }
        }

        // --- 1. TRANSLATOR API ---
        class TranslatorService {
            static async translate(text, sourceLang) {
                const shortLang = sourceLang.split('-')[0];
                if (shortLang === 'en' || !text.trim()) return text;
                try {
                    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${shortLang}&tl=en&dt=t&q=${encodeURIComponent(text)}`;
                    const response = await fetch(url);
                    const data = await response.json();
                    let translatedText = '';
                    data[0].forEach(sentence => { translatedText += sentence[0]; });
                    return translatedText;
                } catch (error) { return text; }
            }
        }

        // --- 1.5. OFFLINE QUEUE MANAGER ---
        class OfflineQueueManager {
            constructor(app) {
                this.app = app;
                this.queue = JSON.parse(localStorage.getItem('zeronet_offline_queue')) || [];
            }

            enqueue(event, data) {
                this.queue.push({ event, data, timestamp: Date.now() });
                this.save();
                this.app.ui.updateOfflineBadge(this.queue.length);
                this.app.ui.logTerminal('QUEUE', `Packet [${event}] queued locally (Offline)`, 'log-error');
            }

            save() {
                localStorage.setItem('zeronet_offline_queue', JSON.stringify(this.queue));
            }

            flush(socket) {
                if (this.queue.length === 0) return;
                this.app.ui.logTerminal('QUEUE', `Flushing ${this.queue.length} offline packets to mesh...`, 'log-tx');

                this.queue.forEach(item => {
                    socket.emit(item.event, item.data);
                });

                this.queue = [];
                this.save();
                this.app.ui.updateOfflineBadge(0);
            }
        }

        // Tactical Distance Formula (Haversine)
        function calculateDistanceMeters(lat1, lon1, lat2, lon2) {
            if (lat1 == null || lon1 == null || lat2 == null || lon2 == null) return null;
            const R = 6371e3;
            const p1 = lat1 * Math.PI / 180;
            const p2 = lat2 * Math.PI / 180;
            const dp = (lat2 - lat1) * Math.PI / 180;
            const dl = (lon2 - lon1) * Math.PI / 180;
            const a = Math.sin(dp / 2) * Math.sin(dp / 2) +
                      Math.cos(p1) * Math.cos(p2) *
                      Math.sin(dl / 2) * Math.sin(dl / 2);
            const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            return R * c;
        }

        function formatDistance(meters) {
            if (meters == null || isNaN(meters)) return "--";
            if (meters < 1000) return `${Math.round(meters)}m`;
            return `${(meters / 1000).toFixed(2)}km`;
        }

        // --- 2. MULTI-TRANSPORT MESH NETWORK (SOCKET.IO + MQTT + BROADCASTCHANNEL) ---
        class ServerNetwork {
            constructor(appContext) {
                this.app = appContext;
                this.deviceId = generateID('NODE');
                this.txCount = 0; this.rxCount = 0;
                document.getElementById('local-device-id').innerText = this.deviceId;

                // 1. Web BroadcastChannel (Zero-latency cross-tab communication)
                this.bc = null;
                if (typeof BroadcastChannel !== 'undefined') {
                    try {
                        this.bc = new BroadcastChannel('zeronet_mesh_bus');
                        this.bc.onmessage = (event) => {
                            if (event.data && event.data.originDeviceId !== this.deviceId) {
                                this.handleRelayPacket(event.data);
                            }
                        };
                    } catch (e) { console.warn('[BC] BroadcastChannel unavailable', e); }
                }

                // 2. Socket.IO (Local server or custom backend)
                this.socket = null;
                if (typeof io !== 'undefined') {
                    try {
                        this.socket = io({ reconnectionAttempts: 5, timeout: 5000 });
                        this.socket.on('connect', () => {
                            this.setServerStatus('ONLINE', 'text-emerald-400 font-bold font-mono', 'led active');
                            this.app.ui.logTerminal('SERVER', `Authenticated to primary WebSocket gateway`);
                            this.socket.emit('request_sync');
                            this.broadcastPresence();
                            this.app.offlineQueue.flush(this.socket);
                        });

                        this.socket.on('disconnect', () => {
                            if (!this.mqttConnected) {
                                this.setServerStatus('MESH ONLY', 'text-amber-400 font-bold font-mono', 'led active');
                            }
                            this.app.ui.logTerminal('SERVER', `Primary socket link offline. Operating over mesh relay.`, 'log-tx');
                        });

                        this.socket.on('node_presence_relay', (nodeData) => {
                            this.handleRelayPacket({ type: 'presence', data: nodeData, originDeviceId: nodeData.nodeId });
                        });

                        this.socket.on('node_location_relay', (locData) => {
                            this.handleRelayPacket({ type: 'location', data: locData, originDeviceId: locData.nodeId });
                        });

                        this.socket.on('node_disconnect_relay', (discData) => {
                            this.handleRelayPacket({ type: 'disconnect', data: discData, originDeviceId: discData.nodeId });
                        });

                        this.socket.on('mesh_relay', (packetStr) => {
                            this.handleIncomingPacket(packetStr);
                        });

                        this.socket.on('mesh_chat_relay', (chatData) => {
                            this.app.receiveChat(chatData);
                        });

                        this.socket.on('sos_override_alarm', (sosData) => {
                            this.handleIncomingSOS(sosData);
                        });

                        // MoES / NCMRWF Nowcast Data Response
                        this.socket.on('nowcast_data', (data) => {
                            if (this.app.nowcast) this.app.nowcast.onNowcastData(data);
                        });

                        // Incoming nowcast warning relay from another node
                        this.socket.on('nowcast_warning_relay', (warningData) => {
                            if (this.app.nowcast) this.app.nowcast.onIncomingWarning(warningData);
                        });

                        this.socket.on('initial_sync', (data) => {
                            this.app.ui.logTerminal('SYNC', `Hydrating records and active mesh nodes...`, 'log-rx');
                            if (data.patients) {
                                data.patients.forEach(p => {
                                    this.app.db.savePatient(p);
                                    if (this.app.map && this.app.map.initialized) this.app.map.plotPatient(p);
                                });
                                this.app.ui.updateLedger(this.app.db.records);
                            }
                            if (data.chats) {
                                const chatBox = document.getElementById('chat-messages');
                                chatBox.innerHTML = '<div class="text-center text-xs text-slate-500 font-mono my-2 border-b border-slate-800 pb-2">SECURE COMMS CHANNEL OPENED</div>';
                                data.chats.forEach(c => {
                                    const isSelf = this.app.auth && c.senderId === this.app.auth.username;
                                    this.app.ui.renderChatMessage(c, isSelf);
                                });
                            }
                            if (data.nodes) {
                                data.nodes.forEach(n => {
                                    if (n.nodeId !== this.deviceId) {
                                        this.app.meshNodes[n.nodeId] = n;
                                        if (this.app.map && this.app.map.initialized) this.app.map.plotOrUpdateNodeMarker(n);
                                    }
                                });
                            }
                        });
                    } catch (e) { console.warn('[SOCKET] Init failed', e); }
                }

                // 3. MQTT over Secure WebSockets (The Global Vercel Relay)
                this.mqttClient = null;
                this.mqttConnected = false;
                this.initMQTTRelay();

                // Periodic presence heartbeat every 12 seconds
                setInterval(() => {
                    if (this.app.auth && this.app.auth.currentUser) {
                        this.broadcastPresence();
                    }
                }, 12000);
            }

            initMQTTRelay() {
                if (typeof mqtt === 'undefined') return;
                try {
                    // Resilient public broker for serverless Vercel deployments
                    const brokerUrl = 'wss://broker.emqx.io:8084/mqtt';
                    this.mqttClient = mqtt.connect(brokerUrl, {
                        clientId: 'zeronet_' + this.deviceId + '_' + Math.random().toString(16).substring(2, 8),
                        keepalive: 45,
                        clean: true,
                        reconnectPeriod: 3000
                    });

                    this.mqttClient.on('connect', () => {
                        this.mqttConnected = true;
                        console.log('[MQTT] Connected to global resilient mesh relay broker');
                        this.mqttClient.subscribe('zeronet/v3/mesh/#');
                        this.setServerStatus('ONLINE (GLOBAL)', 'text-emerald-400 font-bold font-mono', 'led active');
                        this.app.ui.logTerminal('MESH', `Connected to global satellite relay [MQTT/WSS]`);
                        this.broadcastPresence();
                    });

                    this.mqttClient.on('message', (topic, payloadRaw) => {
                        try {
                            const envelope = JSON.parse(payloadRaw.toString());
                            if (envelope.originDeviceId === this.deviceId) return; // Ignore own echoes
                            this.handleRelayPacket(envelope);
                        } catch (err) { }
                    });

                    this.mqttClient.on('error', (err) => {
                        console.warn('[MQTT] Broker warning:', err.message);
                    });
                } catch (e) {
                    console.warn('[MQTT] Initialization bypassed:', e);
                }
            }

            setServerStatus(text, cls, ledCls) {
                const stat = document.getElementById('stat-server');
                if (stat) { stat.innerText = text; stat.className = cls; }
                const led = document.getElementById('led-server');
                if (led) { led.className = ledCls; }
                const mob = document.getElementById('stat-server-mobile');
                if (mob) { mob.innerText = `MESH: ${text}`; }
            }

            sendMeshEnvelope(type, data) {
                const envelope = {
                    type: type,
                    data: data,
                    originDeviceId: this.deviceId,
                    timestamp: Date.now()
                };

                // 1. Send via Socket.io if connected
                if (this.socket && this.socket.connected) {
                    if (type === 'presence') this.socket.emit('node_presence', data);
                    else if (type === 'location') this.socket.emit('node_location', data);
                    else if (type === 'patient') this.socket.emit('mesh_tx', JSON.stringify(data));
                    else if (type === 'chat') this.socket.emit('mesh_chat', data);
                    else if (type === 'sos') this.socket.emit('dispatch_sos', data);
                    else if (type === 'nowcast_request') this.socket.emit('request_nowcast', data);
                    else if (type === 'nowcast_warning') this.socket.emit('broadcast_nowcast_warning', data);
                }

                // 2. Send via MQTT Global Relay if connected (critical for Vercel)
                if (this.mqttClient && this.mqttConnected) {
                    try {
                        this.mqttClient.publish(`zeronet/v3/mesh/${type}`, JSON.stringify(envelope));
                    } catch (e) { }
                }

                // 3. Send via BroadcastChannel for multi-tab
                if (this.bc) {
                    try { this.bc.postMessage(envelope); } catch (e) { }
                }

                return envelope;
            }

            broadcastPresence() {
                const role = this.app.auth ? this.app.auth.role : 'GUEST';
                const user = this.app.auth ? this.app.auth.currentUser : 'ANONYMOUS';
                const nodeData = {
                    nodeId: this.deviceId,
                    role: role,
                    username: user,
                    lat: this.app.gps.lat,
                    lng: this.app.gps.lng,
                    accuracy: this.app.gps.accuracy || 10,
                    source: this.app.gps.source,
                    lastSeen: Date.now(),
                    isMobile: /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent)
                };
                this.sendMeshEnvelope('presence', nodeData);
            }

            broadcastLocation(lat, lng, accuracy) {
                const role = this.app.auth ? this.app.auth.role : 'GUEST';
                const locData = {
                    nodeId: this.deviceId,
                    role: role,
                    lat: lat,
                    lng: lng,
                    accuracy: accuracy,
                    timestamp: Date.now()
                };
                this.sendMeshEnvelope('location', locData);
            }

            broadcastPatient(patientData) {
                patientData.relayNode = this.deviceId;
                this.sendMeshEnvelope('patient', patientData);
                document.getElementById('stat-tx').innerText = ++this.txCount;
                this.app.ui.logTerminal('TX_MESH', `Broadcast triage payload across mesh channels...`, 'log-tx');
            }

            sendChat(message) {
                const chatData = {
                    senderId: this.deviceId,
                    role: this.app.auth.role || 'UNKNOWN',
                    username: this.app.auth.currentUser || 'ANON',
                    message: message,
                    timestamp: getTimestamp()
                };
                this.sendMeshEnvelope('chat', chatData);
                this.app.ui.logTerminal('COMMS_TX', `Sent direct message to mesh network`, 'log-tx');
                return chatData;
            }

            dispatchSOS(message, targetContacts, lat, lng) {
                const sosData = {
                    senderId: this.deviceId,
                    message: message,
                    contacts: targetContacts,
                    lat: lat,
                    lng: lng,
                    role: this.app.auth.role || 'USER',
                    timestamp: Date.now()
                };
                this.sendMeshEnvelope('sos', sosData);
                this.app.ui.logTerminal('DISPATCH', `Emergency SOS broadcast sent to satellite mesh!`);
            }

            handleRelayPacket(envelope) {
                if (!envelope || !envelope.type) return;

                switch (envelope.type) {
                    case 'presence': {
                        const node = envelope.data;
                        if (!node || !node.nodeId || node.nodeId === this.deviceId) return;
                        const isNew = !this.app.meshNodes[node.nodeId];
                        this.app.meshNodes[node.nodeId] = node;
                        if (this.app.map && this.app.map.initialized) {
                            this.app.map.plotOrUpdateNodeMarker(node);
                            this.app.map.updateDistanceIndicator();
                        }
                        if (isNew) {
                            const nodeLat = (node.lat != null && !isNaN(node.lat)) ? Number(node.lat).toFixed(4) : '--';
                            const nodeLng = (node.lng != null && !isNaN(node.lng)) ? Number(node.lng).toFixed(4) : '--';
                            this.app.ui.logTerminal('MESH_NODE', `Active ${node.role} discovered: ${node.nodeId} [${nodeLat}, ${nodeLng}]`, 'log-rx');
                            // Reciprocate presence so newly joined node immediately discovers us
                            setTimeout(() => this.broadcastPresence(), 1000);
                        }
                        break;
                    }
                    case 'location': {
                        const loc = envelope.data;
                        if (!loc || !loc.nodeId || loc.nodeId === this.deviceId) return;
                        if (this.app.meshNodes[loc.nodeId]) {
                            Object.assign(this.app.meshNodes[loc.nodeId], loc);
                        } else {
                            this.app.meshNodes[loc.nodeId] = loc;
                        }
                        if (this.app.map && this.app.map.initialized) {
                            this.app.map.plotOrUpdateNodeMarker(this.app.meshNodes[loc.nodeId]);
                            this.app.map.updateDistanceIndicator();
                        }
                        break;
                    }
                    case 'patient': {
                        this.handleIncomingPacket(envelope.data);
                        break;
                    }
                    case 'chat': {
                        this.app.receiveChat(envelope.data);
                        break;
                    }
                    case 'sos': {
                        this.handleIncomingSOS(envelope.data);
                        break;
                    }
                    case 'disconnect': {
                        const d = envelope.data;
                        if (d && d.nodeId && this.app.meshNodes[d.nodeId]) {
                            delete this.app.meshNodes[d.nodeId];
                            if (this.app.map && this.app.map.initialized) {
                                this.app.map.removeNodeMarker(d.nodeId);
                                this.app.map.updateDistanceIndicator();
                            }
                            this.app.ui.logTerminal('MESH', `Node ${d.nodeId} went offline.`);
                        }
                        break;
                    }
                }
            }

            handleIncomingPacket(rawPacket) {
                try {
                    const data = typeof rawPacket === 'string' ? JSON.parse(rawPacket) : rawPacket;
                    if (!data || !data.id) return;
                    document.getElementById('stat-rx').innerText = ++this.rxCount;
                    this.app.ui.logTerminal('RX_MESH', `Inbound telemetry casualty ${data.id} from ${data.relayNode}`, 'log-rx');
                    this.app.db.savePatient(data);
                    this.app.ui.updateLedger(this.app.db.records);
                    if (this.app.map && this.app.map.initialized) this.app.map.plotPatient(data);
                } catch (e) { }
            }

            handleIncomingSOS(sosDataRaw) {
                const sosData = typeof sosDataRaw === 'string' ? JSON.parse(sosDataRaw) : sosDataRaw;
                if (!sosData || sosData.senderId === this.deviceId) return;

                this.app.ui.logTerminal('SOS_ALERT', `CRITICAL SOS ALARM FROM ${sosData.senderId}`, 'log-sos');

                const senderEl = document.getElementById('sos-alarm-sender');
                const sosLat = (sosData.lat != null && !isNaN(sosData.lat)) ? Number(sosData.lat).toFixed(4) : '0.0000';
                const sosLng = (sosData.lng != null && !isNaN(sosData.lng)) ? Number(sosData.lng).toFixed(4) : '0.0000';
                if (senderEl) senderEl.innerText = `ORIGIN: ${sosData.senderId} | GPS: ${sosLat}, ${sosLng}`;
                const msgEl = document.getElementById('sos-alarm-msg');
                if (msgEl) msgEl.innerText = `"${sosData.message}"`;
                const overlay = document.getElementById('sos-alarm-overlay');
                if (overlay) overlay.style.display = 'flex';

                const sosRecord = {
                    id: `SOS-${sosData.senderId.split('-')[1] || Math.floor(Math.random() * 9000)}`,
                    triage: 'RED',
                    symptoms: `[CRITICAL SOS] ${sosData.message}`,
                    lat: sosData.lat,
                    lng: sosData.lng,
                    relayNode: sosData.senderId
                };

                this.app.db.savePatient(sosRecord);
                this.app.ui.updateLedger(this.app.db.records);
                if (this.app.map && this.app.map.initialized) this.app.map.plotPatient(sosRecord);
            }
        }

        // --- 3. INDESTRUCTIBLE 4-TIER GEOLOCATION ENGINE ---
        class GPSModule {
            constructor(app) {
                this.app = app;
                this.lat = 16.5770;
                this.lng = 82.0039;
                this.accuracy = null;
                this.source = 'INIT';
                this.watchId = null;
                this.hasInitialFix = false;
            }

            async getFix() {
                // 1. Run IP Geolocation lookup immediately in background
                this.fetchIPFallback();

                return new Promise((resolve) => {
                    if (!("geolocation" in navigator)) {
                        this.updateStatus('NO_GPS_API');
                        return resolve(false);
                    }

                    let finished = false;

                    const onSuccess = (pos) => {
                        this.lat = pos.coords.latitude;
                        this.lng = pos.coords.longitude;
                        this.accuracy = Math.round(pos.coords.accuracy);
                        this.source = 'SATELLITE_GPS';
                        this.hasInitialFix = true;
                        this.updateStatus(`FIX (±${this.accuracy}m)`);
                        this.app.onLocationUpdated(this.lat, this.lng, this.accuracy);
                        this.startContinuousWatch();
                        if (!finished) { finished = true; resolve(true); }
                    };

                    const onError = (err) => {
                        console.warn(`[GPS] High-accuracy attempt (${err.code}: ${err.message}). Retrying standard accuracy...`);
                        // Fallback attempt with enableHighAccuracy: false
                        navigator.geolocation.getCurrentPosition(
                            onSuccess,
                            (err2) => {
                                console.warn(`[GPS] Standard attempt failed (${err2.message}). Using IP / fallback.`);
                                if (!this.hasInitialFix) {
                                    this.updateStatus(this.source === 'IP_GEO' ? 'IP ESTIMATE' : 'LOCAL PIN');
                                }
                                this.startContinuousWatch();
                                if (!finished) { finished = true; resolve(false); }
                            },
                            { enableHighAccuracy: false, timeout: 8000, maximumAge: 30000 }
                        );
                    };

                    // First try High Accuracy HTML5 Geolocation with 12s timeout
                    navigator.geolocation.getCurrentPosition(
                        onSuccess,
                        onError,
                        { enableHighAccuracy: true, timeout: 12000, maximumAge: 5000 }
                    );
                });
            }

            startContinuousWatch() {
                if (!("geolocation" in navigator) || this.watchId !== null) return;
                this.watchId = navigator.geolocation.watchPosition(
                    (pos) => {
                        this.lat = pos.coords.latitude;
                        this.lng = pos.coords.longitude;
                        this.accuracy = Math.round(pos.coords.accuracy);
                        this.source = 'LIVE_GPS';
                        this.hasInitialFix = true;
                        this.updateStatus(`LIVE (±${this.accuracy}m)`);
                        this.app.onLocationUpdated(this.lat, this.lng, this.accuracy);
                    },
                    (err) => { },
                    { enableHighAccuracy: true, timeout: 15000, maximumAge: 5000 }
                );
            }

            async fetchIPFallback() {
                try {
                    const res = await fetch('https://api.bigdatacloud.net/data/reverse-geocode-client');
                    if (res.ok) {
                        const data = await res.json();
                        if (data.latitude && data.longitude && !this.hasInitialFix) {
                            this.lat = data.latitude;
                            this.lng = data.longitude;
                            this.accuracy = 5000;
                            this.source = 'IP_GEO';
                            this.updateStatus(`EST (${data.city || 'Regional'})`);
                            this.app.onLocationUpdated(this.lat, this.lng, 5000);
                        }
                    }
                } catch (e) {
                    try {
                        const res2 = await fetch('https://ipapi.co/json/');
                        if (res2.ok) {
                            const data2 = await res2.json();
                            if (data2.latitude && data2.longitude && !this.hasInitialFix) {
                                this.lat = data2.latitude;
                                this.lng = data2.longitude;
                                this.accuracy = 5000;
                                this.source = 'IP_GEO';
                                this.updateStatus(`EST (${data2.city || 'Regional'})`);
                                this.app.onLocationUpdated(this.lat, this.lng, 5000);
                            }
                        }
                    } catch (err2) { }
                }
            }

            setManualPosition(lat, lng) {
                this.lat = lat;
                this.lng = lng;
                this.accuracy = 1;
                this.source = 'MANUAL_PIN';
                this.hasInitialFix = true;
                this.updateStatus('MANUAL PIN');
                this.app.onLocationUpdated(this.lat, this.lng, 1);
                this.app.ui.logTerminal('GPS', `Manual coordinate calibrated: [${lat.toFixed(5)}, ${lng.toFixed(5)}]`, 'log-tx');
            }

            updateStatus(tag) {
                const desktopEl = document.getElementById('stat-gps');
                if (desktopEl) {
                    desktopEl.innerText = `${tag} (${this.lat.toFixed(3)}, ${this.lng.toFixed(3)})`;
                }
                const mobileEl = document.getElementById('stat-gps-mobile');
                if (mobileEl) {
                    mobileEl.innerText = `GPS: ${tag}`;
                }
                const led = document.getElementById('led-gps');
                if (led) {
                    led.className = (this.source.includes('GPS') || this.source.includes('MANUAL')) ? 'led active' : 'led';
                }
                const mobileLed = document.getElementById('led-gps-mobile');
                if (mobileLed) {
                    mobileLed.className = (this.source.includes('GPS') || this.source.includes('MANUAL')) ? 'led active' : 'led';
                }
            }
        }

        // --- 4. DATABASE ---
        class DecentralizedDatabase {
            constructor() { this.records = []; }
            savePatient(patient) { if (!this.records.find(p => p.id === patient.id)) this.records.unshift(patient); }
        }

        // --- 5. NLP ENGINE ---
        class AITriageEngine {
            constructor() {
                this.dictionary = {
                    RED: ['severe bleeding', 'unconscious', 'no breathing', 'fast breathing', 'arterial', 'amputation', 'chest pain', 'gasping', 'shock', 'heavy blood', 'not breathing', 'collapsed', 'choking'],
                    YELLOW: ['cannot walk', 'broken leg', 'fracture', 'stable', 'deep cut', 'burns', 'pain', 'dislocated', 'wound'],
                    GREEN: ['walking', 'minor', 'scrapes', 'bruise', 'arm pain', 'dizzy', 'fine', 'scratched', 'conscious'],
                    BLACK: ['pulseless', 'dead', 'decapitated', 'rigor mortis', 'no respiration', 'fatal']
                };
            }
            analyze(transcript) {
                let text = transcript.toLowerCase();
                let score = { RED: 0, YELLOW: 0, GREEN: 0, BLACK: 0 };
                let extracted = [];
                let formattedText = transcript;

                for (const [color, keywords] of Object.entries(this.dictionary)) {
                    keywords.forEach(word => {
                        if (text.includes(word)) {
                            score[color]++;
                            extracted.push({ word, level: color });
                            const regex = new RegExp(`(${word})`, 'gi');
                            formattedText = formattedText.replace(regex, `<span class="nlp-pill nlp-match-${color.toLowerCase()}">$1</span>`);
                        }
                    });
                }
                let level = null;
                if (score.BLACK > 0) level = 'BLACK';
                else if (score.RED > 0) level = 'RED';
                else if (score.YELLOW > 0) level = 'YELLOW';
                else if (score.GREEN > 0 || text.includes('walk')) level = 'GREEN';

                const symptomsText = extracted.length > 0 ? extracted.map(e => `<span class="nlp-pill nlp-match-${e.level.toLowerCase()}">${e.word}</span>`).join(' ') : '<span class="text-slate-500">No protocol match keywords detected.</span>';

                return { formattedText, symptomsMarkup: symptomsText, rawSymptoms: extracted.map(e => e.word).join(', '), suggestedLevel: level };
            }
        }

        // --- 6. MULTI-LINGUAL VOICE INTERFACE ---
        class VoiceInterface {
            constructor(appContext) {
                this.app = appContext;
                this.isRecording = false;
                this.recognition = null;
                this.nativeTranscript = "";
                const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;

                if (SpeechRec) {
                    this.recognition = new SpeechRec();
                    this.recognition.continuous = true;
                    this.recognition.interimResults = true;

                    this.recognition.onstart = () => {
                        document.getElementById('stat-mic').innerText = "LISTENING";
                        document.getElementById('stat-mic').className = "text-emerald-400 font-bold font-mono";
                        document.getElementById('led-mic').className = "led active";
                        this.app.ui.logTerminal('AUDIO', `Speech ingestion active [Language: ${this.recognition.lang}]`);
                    };
                    this.recognition.onresult = (e) => {
                        let interim = '';
                        for (let i = e.resultIndex; i < e.results.length; ++i) {
                            if (e.results[i].isFinal) this.nativeTranscript += e.results[i][0].transcript + ". ";
                            else interim += e.results[i][0].transcript;
                        }
                        document.getElementById('native-transcript').innerText = this.nativeTranscript + interim;
                    };
                    this.recognition.onerror = (e) => { this.stop(true); };
                }
            }

            toggle() {
                if (this.isRecording) this.stop();
                else this.start();
            }

            start() {
                if (!this.recognition) return alert("Speech Recognition not supported on this browser.");
                this.isRecording = true;
                this.nativeTranscript = "";
                this.recognition.lang = document.getElementById('lang-selector').value;

                document.getElementById('transcription-container').classList.remove('hidden');
                document.getElementById('native-transcript').innerText = "Listening in native dialect...";
                document.getElementById('english-transcript').innerText = "Streaming and analyzing translation...";

                const btn = document.getElementById('btn-toggle-mic');
                btn.classList.add('recording');
                btn.innerHTML = "<i class='fas fa-stop text-lg'></i> <span>STOP RECORDING & RUN AI INTAKE</span>";

                document.querySelectorAll('.triage-card').forEach(b => {
                    b.disabled = true;
                    b.classList.remove('ai-suggested');
                });

                try { this.recognition.start(); } catch (e) { console.error(e); }
            }

            async stop(isError = false) {
                this.isRecording = false;
                document.getElementById('stat-mic').innerText = "STANDBY";
                document.getElementById('stat-mic').className = "text-slate-200 font-mono";
                document.getElementById('led-mic').className = "led";

                const btn = document.getElementById('btn-toggle-mic');
                btn.classList.remove('recording');
                btn.innerHTML = "<i class='fas fa-spinner fa-spin text-lg'></i> <span>PROCESSING NLP & TRANSLATING...</span>";
                btn.disabled = true;

                try { this.recognition.stop(); } catch (e) { }

                if (isError || this.nativeTranscript.trim() === "") {
                    btn.disabled = false;
                    btn.innerHTML = "<i class='fas fa-microphone text-lg'></i> <span>INITIATE VOICE CAPTURE</span>";
                    return;
                }

                const srcLang = document.getElementById('lang-selector').value;
                this.app.ui.logTerminal('AI_TRANSLATE', `Running translation for [${srcLang}] stream...`);
                const englishText = await TranslatorService.translate(this.nativeTranscript, srcLang);
                document.getElementById('english-transcript').innerText = englishText;
                this.app.processIntake(englishText);

                btn.disabled = false;
                btn.innerHTML = "<i class='fas fa-microphone text-lg'></i> <span>INITIATE NEXT VOICE CAPTURE</span>";
            }
        }

        // --- 7. LEAFLET COMMAND MAP WITH MULTI-SESSION TRACKING ---
        class TacticalMap {
            constructor(app) {
                this.app = app;
                this.map = null;
                this.markers = {};
                this.nodeMarkers = {};
                this.selfMarker = null;
                this.initialized = false;
                this.calibrateMode = false;
            }

            init(lat, lng) {
                if (this.initialized) return;
                const container = document.getElementById('map-container');
                if (!container) return;

                this.map = L.map('map-container', { zoomControl: true, attributionControl: false }).setView([lat, lng], 15);
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(this.map);

                // Map Click for Manual Calibration
                this.map.on('click', (e) => {
                    if (this.calibrateMode) {
                        this.app.gps.setManualPosition(e.latlng.lat, e.latlng.lng);
                        this.toggleCalibrateMode(false);
                    }
                });

                // Plot Self Marker
                this.updateSelfMarker(lat, lng);

                // Plot any already discovered mesh nodes
                Object.values(this.app.meshNodes).forEach(node => {
                    this.plotOrUpdateNodeMarker(node);
                });

                this.initialized = true;
                this.app.ui.logTerminal('MAP', `Satellite mapping engine online at [${lat.toFixed(4)}, ${lng.toFixed(4)}]`);

                this.initToolbar();
                this.updateDistanceIndicator();
            }

            initToolbar() {
                const btnMyLoc = document.getElementById('btn-map-my-location');
                if (btnMyLoc) {
                    btnMyLoc.onclick = () => this.centerOnSelf();
                }

                const btnAdmin = document.getElementById('btn-map-focus-admin');
                if (btnAdmin) {
                    btnAdmin.onclick = () => this.centerOnAdmin();
                }

                const btnUsers = document.getElementById('btn-map-focus-users');
                if (btnUsers) {
                    btnUsers.onclick = () => this.centerOnResponders();
                }

                const btnFitAll = document.getElementById('btn-map-fit-all');
                if (btnFitAll) {
                    btnFitAll.onclick = () => this.fitAll();
                }

                const btnCalib = document.getElementById('btn-map-calibrate');
                if (btnCalib) {
                    btnCalib.onclick = () => this.toggleCalibrateMode();
                }
            }

            updateSelfMarker(lat, lng) {
                if (!this.map) return;
                const role = this.app.auth ? this.app.auth.role : 'OPERATOR';
                const user = this.app.auth ? this.app.auth.currentUser : 'ANONYMOUS';
                const isUserRole = role === 'USER';
                const labelText = isUserRole ? 'YOU (RESPONDER)' : 'YOU (ADMIN HQ)';
                const ringClass = isUserRole ? 'radar-user' : 'radar-admin';
                const coreClass = isUserRole ? 'core-user' : 'core-admin';
                const labelClass = isUserRole ? 'label-user' : 'label-admin';
                const iconHtml = isUserRole ? '<i class="fas fa-person-walking"></i>' : '<i class="fas fa-shield-halved"></i>';

                const icon = L.divIcon({
                    className: 'custom-map-icon',
                    html: `
                        <div class="marker-container">
                            <div class="radar-ring ${ringClass}"></div>
                            <div class="marker-core ${coreClass}">${iconHtml}</div>
                            <div class="marker-label ${labelClass}">${labelText}</div>
                        </div>
                    `,
                    iconSize: [44, 44],
                    iconAnchor: [22, 22]
                });

                if (this.selfMarker) {
                    this.selfMarker.setLatLng([lat, lng]);
                    this.selfMarker.setIcon(icon);
                } else {
                    this.selfMarker = L.marker([lat, lng], { icon: icon, zIndexOffset: 1000 }).addTo(this.map);
                    this.selfMarker.bindPopup(`
                        <div style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 12px; color: #0b1120; min-width: 160px;">
                            <div style="font-weight: 800; font-size: 14px; color: #0284c7; margin-bottom: 2px;">📍 ACTIVE OPERATOR (YOU)</div>
                            <div>Identity: <b>${user.toUpperCase()}</b> [${role}]</div>
                            <div>Node ID: <b class="font-mono text-xs">${this.app.serverNet.deviceId}</b></div>
                            <div style="margin-top: 4px; font-family: monospace; font-size: 11px; color: #475569;">GPS: ${lat.toFixed(5)}, ${lng.toFixed(5)}</div>
                        </div>
                    `);
                }
            }

            plotOrUpdateNodeMarker(node) {
                if (!this.map || !this.initialized || !node || !node.lat || !node.lng || node.nodeId === this.app.serverNet.deviceId) return;
                const isAdmin = node.role === 'ADMIN';
                const labelText = isAdmin ? `ADMIN: ${node.nodeId.substring(0, 8)}` : `UNIT: ${node.nodeId.substring(0, 8)}`;
                const ringClass = isAdmin ? 'radar-admin' : 'radar-user';
                const coreClass = isAdmin ? 'core-admin' : 'core-user';
                const labelClass = isAdmin ? 'label-admin' : 'label-user';
                const iconHtml = isAdmin ? '<i class="fas fa-building-shield"></i>' : '<i class="fas fa-tower-broadcast"></i>';

                const distMeters = calculateDistanceMeters(this.app.gps.lat, this.app.gps.lng, node.lat, node.lng);
                const distStr = formatDistance(distMeters);

                const icon = L.divIcon({
                    className: 'custom-map-icon',
                    html: `
                        <div class="marker-container">
                            <div class="radar-ring ${ringClass}"></div>
                            <div class="marker-core ${coreClass}">${iconHtml}</div>
                            <div class="marker-label ${labelClass}">${labelText}</div>
                        </div>
                    `,
                    iconSize: [44, 44],
                    iconAnchor: [22, 22]
                });

                const popupHtml = `
                    <div style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 12px; color: #0b1120; min-width: 180px;">
                        <div style="font-weight: 800; font-size: 14px; color: ${isAdmin ? '#b45309' : '#047857'}; margin-bottom: 3px;">
                            ${isAdmin ? '🏛️ COMMAND CENTER (ADMIN)' : '🚶 FIELD RESPONDER (USER)'}
                        </div>
                        <div>Node ID: <b class="font-mono text-xs">${node.nodeId}</b></div>
                        <div>Role: <b>${node.role}</b> ${node.username ? `(${node.username})` : ''}</div>
                        <div>Device: <b>${node.isMobile ? '📱 Mobile' : '💻 Terminal'}</b></div>
                        <div style="margin-top: 4px; padding: 4px 6px; background: #f1f5f9; border-radius: 4px; font-weight: 700; color: #0284c7;">
                            📏 Distance to You: ${distStr}
                        </div>
                        <div style="margin-top: 4px; font-family: monospace; font-size: 11px; color: #64748b;">
                            GPS: ${node.lat.toFixed(5)}, ${node.lng.toFixed(5)}
                        </div>
                        <div style="margin-top: 6px;">
                            <button onclick="window.zeronetApp.ui.clickTab('workspace-comms')" 
                                style="background: #0284c7; color: white; border: none; padding: 5px 8px; border-radius: 4px; font-size: 11px; font-weight: 700; cursor: pointer; width: 100%;">
                                💬 Open Direct Comms
                            </button>
                        </div>
                    </div>
                `;

                if (this.nodeMarkers[node.nodeId]) {
                    this.nodeMarkers[node.nodeId].setLatLng([node.lat, node.lng]);
                    this.nodeMarkers[node.nodeId].setIcon(icon);
                    this.nodeMarkers[node.nodeId].setPopupContent(popupHtml);
                } else {
                    const marker = L.marker([node.lat, node.lng], { icon: icon, zIndexOffset: 900 }).addTo(this.map);
                    marker.bindPopup(popupHtml);
                    this.nodeMarkers[node.nodeId] = marker;
                }
            }

            removeNodeMarker(nodeId) {
                if (this.nodeMarkers[nodeId]) {
                    this.map.removeLayer(this.nodeMarkers[nodeId]);
                    delete this.nodeMarkers[nodeId];
                }
            }

            updateDistanceIndicator() {
                const badge = document.getElementById('map-distance-badge');
                const val = document.getElementById('map-distance-val');
                if (!badge || !val) return;

                const nodes = Object.values(this.app.meshNodes);
                if (nodes.length === 0) {
                    badge.classList.add('hidden');
                    return;
                }

                const role = this.app.auth ? this.app.auth.role : 'USER';
                const targetNode = role === 'USER' 
                    ? nodes.find(n => n.role === 'ADMIN') || nodes[0]
                    : nodes.find(n => n.role === 'USER') || nodes[0];

                if (targetNode && targetNode.lat && targetNode.lng) {
                    const distMeters = calculateDistanceMeters(this.app.gps.lat, this.app.gps.lng, targetNode.lat, targetNode.lng);
                    badge.classList.remove('hidden');
                    val.innerText = `${targetNode.role}: ${formatDistance(distMeters)}`;
                } else {
                    badge.classList.add('hidden');
                }
            }

            centerOnSelf() {
                if (this.map) {
                    this.map.setView([this.app.gps.lat, this.app.gps.lng], 16, { animate: true });
                    if (this.selfMarker) this.selfMarker.openPopup();
                }
            }

            centerOnAdmin() {
                const adminNode = Object.values(this.app.meshNodes).find(n => n.role === 'ADMIN');
                if (adminNode) {
                    this.map.setView([adminNode.lat, adminNode.lng], 16, { animate: true });
                    if (this.nodeMarkers[adminNode.nodeId]) this.nodeMarkers[adminNode.nodeId].openPopup();
                } else if (this.app.auth && this.app.auth.role === 'ADMIN') {
                    this.centerOnSelf();
                } else {
                    alert("No remote Admin Command Center node is currently active on the mesh.");
                }
            }

            centerOnResponders() {
                const userNodes = Object.values(this.app.meshNodes).filter(n => n.role === 'USER');
                if (userNodes.length > 0) {
                    if (userNodes.length === 1) {
                        this.map.setView([userNodes[0].lat, userNodes[0].lng], 16, { animate: true });
                        if (this.nodeMarkers[userNodes[0].nodeId]) this.nodeMarkers[userNodes[0].nodeId].openPopup();
                    } else {
                        const bounds = L.latLngBounds(userNodes.map(n => [n.lat, n.lng]));
                        this.map.fitBounds(bounds, { padding: [50, 50] });
                    }
                } else if (this.app.auth && this.app.auth.role === 'USER') {
                    this.centerOnSelf();
                } else {
                    alert("No remote Field Responder nodes currently active on the mesh.");
                }
            }

            fitAll() {
                if (!this.map) return;
                const points = [[this.app.gps.lat, this.app.gps.lng]];
                Object.values(this.app.meshNodes).forEach(n => {
                    if (n.lat && n.lng) points.push([n.lat, n.lng]);
                });
                this.app.db.records.forEach(p => {
                    if (p.lat && p.lng) points.push([p.lat, p.lng]);
                });

                if (points.length === 1) {
                    this.map.setView(points[0], 15);
                } else {
                    this.map.fitBounds(L.latLngBounds(points), { padding: [50, 50] });
                }
            }

            toggleCalibrateMode(force) {
                this.calibrateMode = typeof force === 'boolean' ? force : !this.calibrateMode;
                const container = document.getElementById('map-container');
                const btnText = document.getElementById('calibrate-btn-text');
                const btn = document.getElementById('btn-map-calibrate');

                if (this.calibrateMode) {
                    if (container) container.classList.add('calibrate-active');
                    if (btnText) btnText.innerText = 'Click Map to Place Pin!';
                    if (btn) btn.className = btn.className.replace('bg-indigo-950/50', 'bg-indigo-600');
                    this.app.ui.logTerminal('MAP', 'Calibration mode active: Click anywhere on the map to set your GPS coordinate.', 'log-tx');
                } else {
                    if (container) container.classList.remove('calibrate-active');
                    if (btnText) btnText.innerText = 'Tap to Calibrate';
                    if (btn) btn.className = btn.className.replace('bg-indigo-600', 'bg-indigo-950/50');
                }
            }

            plotPatient(p) {
                if (!this.initialized || this.markers[p.id]) return;
                let color = '#94a3b8';
                if (p.triage === 'RED') color = '#ef4444';
                if (p.triage === 'YELLOW') color = '#f59e0b';
                if (p.triage === 'GREEN') color = '#10b981';

                const marker = L.circleMarker([p.lat, p.lng], {
                    radius: 10,
                    fillColor: color,
                    color: '#0b1120',
                    weight: 3,
                    fillOpacity: 0.95
                }).addTo(this.map);

                marker.bindPopup(`
                    <div style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 12px; color: #0b1120;">
                        <div style="font-weight: 800; font-size: 14px;">${p.id}</div>
                        <div style="margin: 4px 0;">Priority: <b style="color: ${color}">${p.triage}</b></div>
                        <div>Symptoms: ${p.symptoms}</div>
                        <div style="font-size: 11px; color: #64748b; margin-top: 4px;">Relayed by: ${p.relayNode}</div>
                    </div>
                `);

                this.markers[p.id] = marker;
                this.updateCounters();
            }

            updateCounters() {
                const records = this.app.db.records;
                const redCount = records.filter(r => r.triage === 'RED').length;
                const yelCount = records.filter(r => r.triage === 'YELLOW').length;
                const grnCount = records.filter(r => r.triage === 'GREEN').length;

                const rEl = document.getElementById('map-count-red');
                const yEl = document.getElementById('map-count-yellow');
                const gEl = document.getElementById('map-count-green');
                if (rEl) rEl.innerText = redCount;
                if (yEl) yEl.innerText = yelCount;
                if (gEl) gEl.innerText = grnCount;
            }
        }

        // --- 8. MoES / NCMRWF AI NOWCASTING ENGINE (CLIENT-SIDE CONTROLLER) ---
        class NowcastEngine {
            constructor(app) {
                this.app = app;
                this.currentLeadHours = 3;
                this.currentHotspot = 'Kedarnath';
                this.lastData = null;
                this.playInterval = null;
                this.isPlaying = false;
                this.nowcastMap = null;
                this.nowcastMapInit = false;
                this.convectiveLayer = null;
                this.floodLayer = null;
                this.windLayer = null;

                const hotspotCoords = {
                    'Kedarnath':  { lat: 30.7346, lng: 79.0669 },
                    'Wayanad':    { lat: 11.6040, lng: 76.0834 },
                    'Subansiri':  { lat: 27.0000, lng: 93.5000 },
                    'Mumbai':     { lat: 19.0760, lng: 72.8777 },
                    'MyGPS':      { lat: null, lng: null }
                };
                this.hotspotCoords = hotspotCoords;

                this.bindUI();
            }

            bindUI() {
                // Hotspot selector
                const hotspotSel = document.getElementById('nowcast-hotspot-select');
                if (hotspotSel) {
                    hotspotSel.addEventListener('change', () => {
                        this.currentHotspot = hotspotSel.value;
                        this.requestNowcast();
                    });
                }

                // Horizon step buttons (+2h to +6h)
                document.querySelectorAll('.nowcast-horizon-btn').forEach(btn => {
                    btn.addEventListener('click', () => {
                        this.setLeadHours(parseInt(btn.getAttribute('data-hours')));
                    });
                });

                // Auto-play toggle
                const playBtn = document.getElementById('btn-nowcast-play');
                if (playBtn) {
                    playBtn.addEventListener('click', () => this.togglePlay());
                }

                // Refresh/Re-compute
                const refreshBtn = document.getElementById('btn-nowcast-refresh');
                if (refreshBtn) {
                    refreshBtn.addEventListener('click', () => this.requestNowcast());
                }

                // Broadcast early warning to mesh
                const broadcastBtn = document.getElementById('btn-broadcast-nowcast');
                if (broadcastBtn) {
                    broadcastBtn.addEventListener('click', () => this.broadcastWarning());
                }
            }

            setLeadHours(hours) {
                this.currentLeadHours = hours;
                // Update horizon button active states
                document.querySelectorAll('.nowcast-horizon-btn').forEach(btn => {
                    const h = parseInt(btn.getAttribute('data-hours'));
                    const isActive = h === hours;
                    btn.className = btn.className
                        .replace(/\bborder-amber-500\b/g, 'border-[var(--border-subtle)]')
                        .replace(/\bbg-amber-950\/40\b/g, 'bg-[var(--bg-canvas)]')
                        .replace(/\btext-amber-300\b/g, 'text-slate-300')
                        .replace(/\bshadow-\[0_0_12px_rgba\(245,158,11,0\.25\)\]/g, '');
                    if (isActive) {
                        btn.classList.remove('border-[var(--border-subtle)]', 'bg-[var(--bg-canvas)]', 'text-slate-300');
                        btn.classList.add('border-amber-500', 'bg-amber-950/40', 'text-amber-300', 'shadow-[0_0_12px_rgba(245,158,11,0.25)]');
                    } else {
                        btn.classList.remove('border-amber-500', 'bg-amber-950/40', 'text-amber-300', 'shadow-[0_0_12px_rgba(245,158,11,0.25)]');
                        btn.classList.add('border-[var(--border-subtle)]', 'bg-[var(--bg-canvas)]', 'text-slate-300');
                    }
                });

                const labelMap = { 2: '+2 HOURS (INCIPIENT)', 3: '+3 HOURS (PEAK CONVECTIVE WINDOW)', 4: '+4 HOURS (PEAK UPDRAFT)', 5: '+5 HOURS (RAINOUT PHASE)', 6: '+6 HOURS (DISPERSAL)' };
                const labelEl = document.getElementById('nowcast-lead-label');
                if (labelEl) labelEl.textContent = labelMap[hours] || `+${hours} HOURS`;
                this.requestNowcast();
            }

            requestNowcast() {
                let lat, lng;
                const coords = this.hotspotCoords[this.currentHotspot];
                if (this.currentHotspot === 'MyGPS' || !coords || coords.lat === null) {
                    lat = this.app.gps.lat;
                    lng = this.app.gps.lng;
                } else {
                    lat = coords.lat;
                    lng = coords.lng;
                }

                const reqData = { lat, lng, leadTime: this.currentLeadHours, hotspot: this.currentHotspot };
                if (this.app.serverNet && this.app.serverNet.socket && this.app.serverNet.socket.connected) {
                    this.app.serverNet.socket.emit('request_nowcast', reqData);
                } else {
                    // Fallback: REST API
                    fetch(`/api/nowcast?lat=${lat}&lng=${lng}&leadTime=${this.currentLeadHours}&hotspot=${encodeURIComponent(this.currentHotspot)}`)
                        .then(r => r.json())
                        .then(data => this.onNowcastData(data))
                        .catch(e => console.warn('[NOWCAST] REST fallback failed', e));
                }
                this.app.ui.logTerminal('NOWCAST', `Requesting inference: ${this.currentHotspot} +${this.currentLeadHours}h`, 'log-tx');
            }

            onNowcastData(data) {
                if (!data) return;
                this.lastData = data;
                const p = data.precursors;
                const s = data.multiTaskScores;

                // Update threat badge
                const badge = document.getElementById('nowcast-threat-badge');
                const threatText = document.getElementById('nowcast-threat-text');
                if (badge && threatText) {
                    const colorMap = {
                        'WARNING (RED)':  'bg-red-950/80 text-red-300 border-red-500/50 shadow-[0_0_15px_rgba(239,68,68,0.3)]',
                        'WATCH (AMBER)':  'bg-amber-950/80 text-amber-300 border-amber-500/50 shadow-[0_0_15px_rgba(245,158,11,0.3)]',
                        'ALERT (YELLOW)': 'bg-yellow-950/80 text-yellow-300 border-yellow-500/50 shadow-[0_0_10px_rgba(234,179,8,0.2)]',
                        'ADVISORY':       'bg-emerald-950/80 text-emerald-300 border-emerald-500/50 shadow-[0_0_8px_rgba(16,185,129,0.2)]'
                    };
                    const cls = colorMap[data.threatLevel] || colorMap['ADVISORY'];
                    badge.className = `px-3 py-1.5 rounded-lg text-xs font-black tracking-wider uppercase flex items-center gap-1.5 border ${cls}`;
                    threatText.textContent = data.threatLevel;
                }

                // Multi-task neural network output heads
                this.updateScoreGauge('thunderstorm', s.thunderstormRisk, [
                    { max: 50, label: 'MODERATE CONVECTION' },
                    { max: 70, label: 'STRONG CELL DEVELOPMENT' },
                    { max: 85, label: 'SEVERE THUNDERSTORM' },
                    { max: 100, label: 'EXTREME CONVECTIVE' }
                ]);
                this.updateScoreGauge('cloudburst', s.cloudburstProb, [
                    { max: 35, label: 'SCATTERED HEAVY RAIN' },
                    { max: 55, label: 'INTENSE RAINFALL' },
                    { max: 70, label: 'POTENTIAL CLOUDBURST' },
                    { max: 100, label: 'CONFIRMED CLOUDBURST' }
                ]);
                this.updateScoreGauge('flood', s.flashFloodHazard, [
                    { max: 35, label: 'LOW RUNOFF RISK' },
                    { max: 55, label: 'ELEVATED INUNDATION' },
                    { max: 75, label: 'FLASH FLOOD WATCH' },
                    { max: 100, label: 'FLASH FLOOD IMMINENT' }
                ]);

                // QPE and DEM channel values
                const qpeEl = document.getElementById('val-qpe-burst');
                if (qpeEl) qpeEl.textContent = `${p.qpeIntensity} mm/h${p.qpeIntensity >= 100 ? ' (>100 mm/h CRITICAL)' : ''}`;
                const demEl = document.getElementById('val-dem-channel');
                if (demEl) demEl.textContent = `Slope ${data.slopeDeg}° • Catchment ${data.basinDrainageFactor}x`;

                // Atmospheric precursor matrix
                this.setText('val-iwv', `${p.iwv} kg/m²`);
                this.setText('val-iwv-rate', `+${p.iwvAccumulationRate} kg/m²/h accumulation`);
                this.setText('val-cape', `${p.cape.toLocaleString()} J/kg`);
                this.setText('val-cin', `CIN: ${p.cin} J/kg ${p.cin <= 15 ? '(Eroded Barrier)' : '(Partial Inhibition)'}`);
                this.setText('val-convergence', `${p.convergence} × 10⁻⁵ s⁻¹`);
                this.setText('val-shear', `0-6km Shear: ${p.shear} m/s${p.shear >= 20 ? ' (Stationary Supercell)' : ''}`);
                this.setText('val-ctt', `${p.cttDropRate} °C/h`);
                this.setText('val-ctt-min', `Min Core CTT: ${p.minCTT} °C`);

                // Nowcast map coordinates
                this.setText('nowcast-map-coords', `${data.lat.toFixed(4)}° N, ${data.lng.toFixed(4)}° E`);

                // XAI Summary
                this.setText('xai-summary-text', data.xaiSummary);

                // XAI Factor bars
                const container = document.getElementById('xai-factors-container');
                if (container && data.xaiFactors) {
                    const colors = ['sky', 'amber', 'purple', 'emerald'];
                    container.innerHTML = data.xaiFactors.map((f, i) => {
                        const c = colors[i % colors.length];
                        const pct = Math.min(100, Math.max(2, f.attribution));
                        return `
                        <div class="flex flex-col gap-1">
                            <div class="flex items-center justify-between text-[0.7rem]">
                                <span class="font-bold text-slate-200">${f.variable}</span>
                                <span class="font-mono text-${c}-400 font-bold">${f.value}</span>
                            </div>
                            <div class="flex items-center gap-2">
                                <div class="flex-1 bg-slate-800 rounded-full h-1.5 overflow-hidden">
                                    <div class="bg-${c}-500 h-1.5 rounded-full transition-all duration-700" style="width:${pct}%"></div>
                                </div>
                                <span class="text-[0.65rem] font-mono text-${c}-400 w-8 text-right">${pct}%</span>
                            </div>
                            <div class="text-[0.65rem] text-slate-500 font-sans">${f.description}</div>
                        </div>`;
                    }).join('');
                }

                // Update nowcast spatial map
                this.updateNowcastMap(data);

                this.app.ui.logTerminal('NOWCAST', `[${data.locationName}] +${data.leadTimeHours}h | Thunderstorm: ${s.thunderstormRisk}% | Cloudburst: ${s.cloudburstProb}% | Flood: ${s.flashFloodHazard}% | Threat: ${data.threatLevel}`, 'log-rx');

                // Auto-trigger warning if critical threshold crossed
                if (s.cloudburstProb >= 70 || s.flashFloodHazard >= 75) {
                    const warningBanner = document.getElementById('btn-broadcast-nowcast');
                    if (warningBanner) {
                        warningBanner.classList.add('animate-pulse');
                        setTimeout(() => warningBanner.classList.remove('animate-pulse'), 3000);
                    }
                    this.app.ui.logTerminal('NOWCAST_ALERT', `⚡ AUTO-THRESHOLD BREACH: Cloudburst ${s.cloudburstProb}% / Flood ${s.flashFloodHazard}% — Consider broadcasting to mesh!`, 'log-sos');
                }
            }

            updateScoreGauge(id, score, thresholds) {
                const scoreEl = document.getElementById(`score-${id}`);
                const barEl = document.getElementById(`bar-${id}`);
                const catEl = document.getElementById(`cat-${id}`);
                if (scoreEl) scoreEl.textContent = `${score}%`;
                if (barEl) {
                    barEl.style.width = `${score}%`;
                    barEl.style.transition = 'width 0.8s cubic-bezier(0.4, 0, 0.2, 1)';
                }
                if (catEl && thresholds) {
                    const match = thresholds.find(t => score <= t.max);
                    catEl.textContent = match ? match.label : thresholds[thresholds.length - 1].label;
                }
            }

            setText(id, value) {
                const el = document.getElementById(id);
                if (el) el.textContent = value;
            }

            initNowcastMap(lat, lng) {
                if (this.nowcastMapInit || typeof L === 'undefined') return;
                const mapEl = document.getElementById('nowcast-spatial-map');
                if (!mapEl) return;
                this.nowcastMapInit = true;

                this.nowcastMap = L.map('nowcast-spatial-map', {
                    zoomControl: true,
                    attributionControl: false
                }).setView([lat, lng], 10);

                // OpenTopoMap for topographic DEM terrain visualization
                L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
                    maxZoom: 17,
                    attribution: 'OpenTopoMap',
                    subdomains: 'abc'
                }).addTo(this.nowcastMap);

                // Legend
                const legend = L.control({ position: 'bottomright' });
                legend.onAdd = () => {
                    const div = L.DomUtil.create('div');
                    div.style.cssText = 'background:rgba(15,20,30,0.9);border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:8px 12px;font-size:10px;color:#e2e8f0;line-height:1.7;font-family:monospace;';
                    div.innerHTML = `
                        <div style="font-weight:bold;margin-bottom:4px;color:#f59e0b;">⚡ NOWCAST LAYERS</div>
                        <div><span style="display:inline-block;width:10px;height:10px;background:rgba(239,68,68,0.5);border-radius:2px;margin-right:5px;"></span>Convective Core</div>
                        <div><span style="display:inline-block;width:10px;height:10px;background:rgba(56,189,248,0.4);border-radius:2px;margin-right:5px;"></span>Flash Flood Hazard</div>
                        <div><span style="display:inline-block;width:10px;height:10px;background:rgba(99,102,241,0.4);border-radius:2px;margin-right:5px;"></span>Wind Convergence</div>
                    `;
                    return div;
                };
                legend.addTo(this.nowcastMap);

                // Ensure map resizes correctly when container becomes visible
                const resizeObserver = new ResizeObserver(() => {
                    if (this.nowcastMap) this.nowcastMap.invalidateSize();
                });
                resizeObserver.observe(mapEl);

                // Add map click listener for custom location nowcasting
                this.nowcastMap.on('click', (e) => {
                    const clat = e.latlng.lat;
                    const clng = e.latlng.lng;
                    this.hotspotCoords['Custom'] = { lat: clat, lng: clng };
                    
                    const customOpt = document.getElementById('opt-custom-loc');
                    if (customOpt) {
                        customOpt.style.display = 'block';
                        customOpt.textContent = `🗺️ Custom Location (${clat.toFixed(4)}, ${clng.toFixed(4)})`;
                    }
                    
                    const sel = document.getElementById('nowcast-hotspot-select');
                    if (sel) {
                        sel.value = 'Custom';
                    }
                    this.currentHotspot = 'Custom';
                    this.requestNowcast();
                });
            }

            updateNowcastMap(data) {
                const { lat, lng } = data;
                const p = data.precursors;
                const s = data.multiTaskScores;

                if (!this.nowcastMapInit) {
                    this.initNowcastMap(lat, lng);
                }
                if (!this.nowcastMap) return;

                this.nowcastMap.setView([lat, lng], 10, { animate: true, duration: 0.8 });

                // Remove old dynamic layers
                if (this.convectiveLayer) this.nowcastMap.removeLayer(this.convectiveLayer);
                if (this.floodLayer) this.nowcastMap.removeLayer(this.floodLayer);
                if (this.windLayer) this.nowcastMap.removeLayer(this.windLayer);
                if (this.epicenterMarker) this.nowcastMap.removeLayer(this.epicenterMarker);

                // Convective core polygon (radius based on CAPE intensity)
                const capeRadius = Math.max(8000, (p.cape / 4000) * 22000);
                this.convectiveLayer = L.circle([lat, lng], {
                    radius: capeRadius,
                    color: '#ef4444',
                    weight: 2,
                    fillColor: '#ef4444',
                    fillOpacity: 0.15,
                    dashArray: '5, 5'
                }).addTo(this.nowcastMap);
                this.convectiveLayer.bindTooltip(`⚡ Convective Core: CAPE ${p.cape.toLocaleString()} J/kg | CTT ${p.cttDropRate}°C/h`, { sticky: true, className: 'leaflet-tooltip-dark' });

                // Flash flood hazard zone (larger, based on slope + cloudburst)
                const floodRadius = Math.max(12000, (data.slopeDeg / 35) * 30000 + (s.flashFloodHazard / 100) * 15000);
                this.floodLayer = L.circle([lat, lng], {
                    radius: floodRadius,
                    color: '#38bdf8',
                    weight: 1.5,
                    fillColor: '#38bdf8',
                    fillOpacity: 0.10
                }).addTo(this.nowcastMap);
                this.floodLayer.bindTooltip(`🌊 Flash Flood Hazard: ${s.flashFloodHazard}% | DEM Slope ${data.slopeDeg}° | Catchment ${data.basinDrainageFactor}x`, { sticky: true, className: 'leaflet-tooltip-dark' });

                // Wind convergence polygon (offset to show vector directionality)
                const convRadius = Math.max(6000, (p.convergence / 8) * 18000);
                this.windLayer = L.circle([lat + 0.04, lng - 0.04], {
                    radius: convRadius,
                    color: '#6366f1',
                    weight: 1.5,
                    fillColor: '#6366f1',
                    fillOpacity: 0.10,
                    dashArray: '3, 6'
                }).addTo(this.nowcastMap);
                this.windLayer.bindTooltip(`💨 Convergence: ${p.convergence} × 10⁻⁵ s⁻¹ | Shear: ${p.shear} m/s`, { sticky: true, className: 'leaflet-tooltip-dark' });

                // Epicenter marker with threat color
                const threatColor = data.threatColor || '#ef4444';
                const epicIcon = L.divIcon({
                    className: '',
                    html: `<div style="width:18px;height:18px;border-radius:50%;background:${threatColor};border:3px solid white;box-shadow:0 0 18px ${threatColor};animation:ping 1s infinite;"></div>`,
                    iconSize: [18, 18],
                    iconAnchor: [9, 9]
                });
                this.epicenterMarker = L.marker([lat, lng], { icon: epicIcon }).addTo(this.nowcastMap);
                this.epicenterMarker.bindPopup(`<div style="font-family:monospace;font-size:11px;line-height:1.8;min-width:200px;"><b style="color:#f59e0b;">${data.locationName}</b><br>Lead Time: +${data.leadTimeHours}h<br>Threat: <b style="color:${threatColor};">${data.threatLevel}</b><br>Elevation: ${data.elevation}m | Slope: ${data.slopeDeg}°<br>IWV: ${p.iwv} kg/m² | CAPE: ${p.cape} J/kg<br>⚡ ${s.thunderstormRisk}% | ⛈ ${s.cloudburstProb}% | 🌊 ${s.flashFloodHazard}%</div>`);
                this.epicenterMarker.openPopup();
            }

            togglePlay() {
                const btn = document.getElementById('btn-nowcast-play');
                const playText = document.getElementById('nowcast-play-text');
                if (this.isPlaying) {
                    clearInterval(this.playInterval);
                    this.isPlaying = false;
                    if (btn) btn.querySelector('i').className = 'fas fa-play text-[10px] text-amber-400';
                    if (playText) playText.textContent = 'Auto Play';
                } else {
                    this.isPlaying = true;
                    if (btn) btn.querySelector('i').className = 'fas fa-pause text-[10px] text-rose-400';
                    if (playText) playText.textContent = 'Playing...';
                    this.currentLeadHours = 2;
                    this.setLeadHours(2);
                    this.playInterval = setInterval(() => {
                        this.currentLeadHours = (this.currentLeadHours < 6) ? this.currentLeadHours + 1 : 2;
                        this.setLeadHours(this.currentLeadHours);
                    }, 2200);
                }
            }

            broadcastWarning() {
                if (!this.lastData) return alert('Run a nowcast inference first before broadcasting.');
                const d = this.lastData;
                const s = d.multiTaskScores;
                const warningPayload = {
                    locationName: d.locationName,
                    lat: d.lat,
                    lng: d.lng,
                    leadTimeHours: d.leadTimeHours,
                    threatLevel: d.threatLevel,
                    thunderstormRisk: s.thunderstormRisk,
                    cloudburstProb: s.cloudburstProb,
                    flashFloodHazard: s.flashFloodHazard,
                    iwv: d.precursors.iwv,
                    cape: d.precursors.cape,
                    cin: d.precursors.cin,
                    cttDropRate: d.precursors.cttDropRate,
                    shear: d.precursors.shear,
                    convergence: d.precursors.convergence,
                    slopeDeg: d.slopeDeg,
                    xaiSummary: d.xaiSummary,
                    originNode: this.app.serverNet ? this.app.serverNet.deviceId : 'COMMAND',
                    timestamp: Date.now()
                };

                if (this.app.serverNet && this.app.serverNet.socket && this.app.serverNet.socket.connected) {
                    this.app.serverNet.socket.emit('broadcast_nowcast_warning', warningPayload);
                }

                this.app.ui.logTerminal('DISPATCH', `⚡ [MoES EARLY WARNING] Broadcast to ZeroNet mesh: ${d.locationName} | ${d.threatLevel} | +${d.leadTimeHours}h | Cloudburst: ${s.cloudburstProb}% | Flood: ${s.flashFloodHazard}%`, 'log-sos');
                alert(`⚡ MoES/NCMRWF Early Warning Broadcast\n\nLocation: ${d.locationName}\nThreat Level: ${d.threatLevel}\nLead Time: +${d.leadTimeHours}h\nCloudburst Probability: ${s.cloudburstProb}%\nFlash Flood Hazard: ${s.flashFloodHazard}%\n\nAlert dispatched to all ZeroNet field responder nodes and SOS relay matrix.`);
            }

            onIncomingWarning(data) {
                if (!data) return;
                this.app.ui.logTerminal('NOWCAST_RX', `⚡ INCOMING EARLY WARNING from ${data.originNode || 'UNKNOWN'}: ${data.locationName} | ${data.threatLevel} | +${data.leadTimeHours}h | Cloudburst: ${data.cloudburstProb}% | Flood: ${data.flashFloodHazard}%`, 'log-sos');

                // Display SOS alarm overlay with the warning
                const overlay = document.getElementById('sos-alarm-overlay');
                const senderEl = document.getElementById('sos-alarm-sender');
                const msgEl = document.getElementById('sos-alarm-msg');
                if (overlay && senderEl && msgEl) {
                    senderEl.textContent = `MoES EARLY WARNING | ${data.locationName} (${data.lat.toFixed(3)}°N, ${data.lng.toFixed(3)}°E)`;
                    msgEl.textContent = `"[+${data.leadTimeHours}h FORECAST] ${data.threatLevel}: Cloudburst ${data.cloudburstProb}% / Flash Flood ${data.flashFloodHazard}%. ${data.xaiSummary || ''}"`;
                    overlay.style.display = 'flex';
                }
            }

            initOnTabSwitch() {
                // Initialize map lazily when the nowcast tab is first opened
                if (!this.nowcastMapInit && this.lastData) {
                    this.updateNowcastMap(this.lastData);
                } else if (!this.nowcastMapInit) {
                    const coords = this.hotspotCoords[this.currentHotspot];
                    const lat = coords && coords.lat ? coords.lat : this.app.gps.lat;
                    const lng = coords && coords.lng ? coords.lng : this.app.gps.lng;
                    this.initNowcastMap(lat, lng);
                }
                if (this.nowcastMap) {
                    setTimeout(() => this.nowcastMap.invalidateSize(), 300);
                }
            }
        }

        // --- 8. UI MANAGER ---
        class UIManager {
            constructor() {
                this.terminal = document.getElementById('terminal');
                document.querySelectorAll('.nav-item').forEach(item => {
                    item.addEventListener('click', (e) => {
                        this.clickTab(e.currentTarget.getAttribute('data-target'));
                    });
                });

                // Ledger Search
                document.getElementById('ledger-search').addEventListener('input', (e) => {
                    const q = e.target.value.toLowerCase();
                    if (window.zeronetApp) {
                        const filtered = window.zeronetApp.db.records.filter(r =>
                            r.id.toLowerCase().includes(q) ||
                            r.triage.toLowerCase().includes(q) ||
                            (r.symptoms && r.symptoms.toLowerCase().includes(q)) ||
                            (r.relayNode && r.relayNode.toLowerCase().includes(q))
                        );
                        this.renderLedgerRows(filtered);
                    }
                });
            }

            updateOfflineBadge(count) {
                const badge = document.getElementById('offline-badge');
                if (count > 0) {
                    badge.classList.remove('hidden');
                    badge.classList.add('flex');
                    document.getElementById('offline-count').innerText = count;
                } else {
                    badge.classList.add('hidden');
                    badge.classList.remove('flex');
                }
            }

            clickTab(targetId) {
                document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
                const btn = document.querySelector(`.nav-item[data-target="${targetId}"]`);
                if (btn) btn.classList.add('active');

                document.querySelectorAll('main > section').forEach(sec => {
                    sec.classList.add('hidden');
                    sec.style.display = 'none';
                });

                const targetSection = document.getElementById(targetId);
                if (targetSection) {
                    targetSection.classList.remove('hidden');
                    targetSection.style.display = 'flex';
                }

                if (targetId === 'workspace-map' && window.zeronetApp && window.zeronetApp.map && window.zeronetApp.map.initialized) {
                    setTimeout(() => {
                        window.zeronetApp.map.map.invalidateSize();
                        window.zeronetApp.map.map.setView([window.zeronetApp.gps.lat, window.zeronetApp.gps.lng], 15);
                    }, 200);
                }

                // Initialize nowcast map and trigger first inference on tab switch
                if (targetId === 'workspace-nowcast' && window.zeronetApp && window.zeronetApp.nowcast) {
                    window.zeronetApp.nowcast.initOnTabSwitch();
                    if (!window.zeronetApp.nowcast.lastData) {
                        window.zeronetApp.nowcast.requestNowcast();
                    }
                }
            }

            logTerminal(mod, text, cls = '') {
                const row = document.createElement('div');
                row.className = `log-row ${cls}`;
                row.innerHTML = `<span class="log-time">[${getTimestamp()}]</span> <span class="log-module">[${mod}]</span> <span>${text}</span>`;
                this.terminal.appendChild(row);
                this.terminal.scrollTop = this.terminal.scrollHeight;
            }

            updateLedger(records) {
                this.renderLedgerRows(records);
            }

            renderLedgerRows(records) {
                const tbody = document.getElementById('ledger-body');
                tbody.innerHTML = '';

                if (records.length === 0) {
                    tbody.innerHTML = `<tr><td colspan="5" class="p-6 text-center text-slate-500 font-mono">No casualty entries recorded yet.</td></tr>`;
                    return;
                }

                records.forEach(p => {
                    let badgeMarkup = "";
                    if (p.triage === 'RED') badgeMarkup = `<span class="px-2.5 py-1 rounded-md text-[0.68rem] font-bold bg-red-950 text-red-300 border border-red-500/40">🔴 RED (T1)</span>`;
                    else if (p.triage === 'YELLOW') badgeMarkup = `<span class="px-2.5 py-1 rounded-md text-[0.68rem] font-bold bg-amber-950 text-amber-300 border border-amber-500/40">🟡 YELLOW (T2)</span>`;
                    else if (p.triage === 'GREEN') badgeMarkup = `<span class="px-2.5 py-1 rounded-md text-[0.68rem] font-bold bg-emerald-950 text-emerald-300 border border-emerald-500/40">🟢 GREEN (T3)</span>`;
                    else badgeMarkup = `<span class="px-2.5 py-1 rounded-md text-[0.68rem] font-bold bg-slate-800 text-slate-300 border border-slate-600">⚫ BLACK (T4)</span>`;

                    const plat = (p.lat != null && !isNaN(p.lat)) ? Number(p.lat).toFixed(4) : '--';
                    const plng = (p.lng != null && !isNaN(p.lng)) ? Number(p.lng).toFixed(4) : '--';

                    tbody.insertAdjacentHTML('beforeend', `
                    <tr class="hover:bg-white/[0.02] transition">
                        <td class="p-3.5 font-mono font-bold text-white">${p.id}</td>
                        <td class="p-3.5">${badgeMarkup}</td>
                        <td class="p-3.5 max-w-[280px] truncate text-slate-300">${p.symptoms}</td>
                        <td class="p-3.5 text-slate-400 font-mono text-[0.72rem]">${plat}, ${plng}</td>
                        <td class="p-3.5 font-mono text-[var(--brand-light)] font-semibold">${p.relayNode}</td>
                    </tr>`);
                });
            }
        }

        // --- 9. MASTER APP CONTROLLER ---
        class ZeroNetApp {
            constructor() {
                this.ui = new UIManager();
                this.db = new DecentralizedDatabase();
                this.meshNodes = {};
                this.gps = new GPSModule(this);
                this.serverNet = new ServerNetwork(this);
                this.ai = new AITriageEngine();
                this.voice = new VoiceInterface(this);
                this.map = null;
                this.nowcast = new NowcastEngine(this);
                this.auth = new AuthManager(this);
                this.draft = null;
                this.offlineQueue = new OfflineQueueManager(this);

                // Initialize badge state
                this.ui.updateOfflineBadge(this.offlineQueue.queue.length);

                this.initCore();
            }

            async initCore() {
                await this.gps.getFix();

                // Chat integration
                document.getElementById('btn-send-chat').addEventListener('click', () => this.sendManualMessage());
                document.getElementById('chat-input').addEventListener('keypress', (e) => {
                    if (e.key === 'Enter') this.sendManualMessage();
                });

                document.getElementById('btn-toggle-mic').addEventListener('click', () => this.voice.toggle());

                // Manual Offline Intake
                document.getElementById('btn-manual-intake').addEventListener('click', () => this.runManualIntake());
                document.getElementById('manual-intake-input').addEventListener('keypress', (e) => {
                    if (e.key === 'Enter') this.runManualIntake();
                });

                ['RED', 'YELLOW', 'GREEN', 'BLACK'].forEach(c => {
                    document.getElementById(`btn-${c}`).addEventListener('click', () => this.commitPatient(c));
                });

                document.getElementById('btn-autofill-sos').addEventListener('click', () => {
                    const latest = this.db.records[0];
                    const symptomInfo = latest ? `Victim [${latest.id}] flagged with: ${latest.symptoms}` : "Immediate triage support required.";
                    document.getElementById('sos-message').value = `[PRIORITY SOS DISPATCH]\nLOCATION: Lat ${this.gps.lat.toFixed(4)}, Lng ${this.gps.lng.toFixed(4)}\nSTATUS: ${symptomInfo}\nREQUEST: Dispatch aeromedical rescue & triage response immediately.`;
                });

                document.getElementById('btn-send-sos').addEventListener('click', () => {
                    const msg = document.getElementById('sos-message').value;
                    if (!msg) return alert("Enter emergency dispatch instructions first!");
                    const contacts = Array.from(document.querySelectorAll('.contact-cb:checked')).map(cb => cb.value);
                    if (contacts.length === 0) return alert("Select at least one destination!");

                    this.serverNet.dispatchSOS(msg, contacts, this.gps.lat, this.gps.lng);
                    alert("🚨 High-Priority SOS Dispatched across satellite and mesh relay nodes.");
                    document.getElementById('sos-message').value = "";
                });
            }

            onLocationUpdated(lat, lng, accuracy) {
                if (this.map && this.map.initialized) {
                    this.map.updateSelfMarker(lat, lng);
                    this.map.updateDistanceIndicator();
                }
                if (this.serverNet) {
                    this.serverNet.broadcastLocation(lat, lng, accuracy);
                }
                if (this.draft) {
                    this.draft.lat = lat;
                    this.draft.lng = lng;
                }
            }

            initAdminTools() {
                if (!this.map) {
                    this.map = new TacticalMap(this);
                    this.map.init(this.gps.lat, this.gps.lng);
                    this.db.records.forEach(p => this.map.plotPatient(p));
                } else {
                    this.map.updateSelfMarker(this.gps.lat, this.gps.lng);
                    this.map.updateDistanceIndicator();
                }
            }

            processIntake(translatedText) {
                if (!translatedText.trim()) return;
                const analysis = this.ai.analyze(translatedText);
                document.getElementById('english-transcript').innerHTML = analysis.formattedText;
                document.getElementById('ai-analysis').innerHTML = `
                    <div class="mb-1">Keywords: ${analysis.symptomsMarkup}</div>
                    <div>Recommended Level: <span class="font-bold text-white uppercase">${analysis.suggestedLevel || 'NONE'}</span></div>
                `;

                this.draft = {
                    id: generateID('VIC'),
                    symptoms: analysis.rawSymptoms || translatedText,
                    lat: this.gps.lat,
                    lng: this.gps.lng
                };

                document.querySelectorAll('.triage-card').forEach(b => {
                    b.disabled = false;
                    b.classList.remove('ai-suggested');
                });

                if (analysis.suggestedLevel) {
                    const suggestedBtn = document.getElementById(`btn-${analysis.suggestedLevel}`);
                    if (suggestedBtn) suggestedBtn.classList.add('ai-suggested');
                }
            }

            commitPatient(color) {
                if (!this.draft) return;
                this.draft.triage = color;
                this.db.savePatient(this.draft);
                this.ui.updateLedger(this.db.records);
                if (this.map) this.map.plotPatient(this.draft);

                this.serverNet.broadcastPatient(this.draft);

                this.draft = null;
                document.getElementById('transcription-container').classList.add('hidden');
                document.querySelectorAll('.triage-card').forEach(b => {
                    b.disabled = true;
                    b.classList.remove('ai-suggested');
                });
            }

            runManualIntake() {
                const inputEl = document.getElementById('manual-intake-input');
                const text = inputEl.value.trim();
                if (!text) return;

                document.getElementById('transcription-container').classList.remove('hidden');
                document.getElementById('native-transcript').innerText = "[MANUAL OFFLINE ENTRY]";
                document.getElementById('english-transcript').innerText = text;

                this.ui.logTerminal('AI_OFFLINE', `Running local NLP heuristics on manual input...`);
                this.processIntake(text);
                inputEl.value = "";
            }

            sendManualMessage() {
                const inputEl = document.getElementById('chat-input');
                const msg = inputEl.value.trim();
                if (!msg) return;

                const chatData = this.serverNet.sendChat(msg);
                this.renderChatMessage(chatData, true); // true = sent by me
                inputEl.value = "";
            }

            receiveChat(chatData) {
                this.ui.logTerminal('COMMS_RX', `Received msg from ${chatData.senderId}`, 'log-rx');
                this.renderChatMessage(chatData, false);
            }

            renderChatMessage(data, isSelf) {
                const chatBox = document.getElementById('chat-messages');
                const alignClass = isSelf ? 'self-end bg-[var(--brand-dark)] border-[var(--brand)] shadow-[0_0_15px_var(--brand-glow)]' : 'self-start bg-[var(--bg-panel)] border-[var(--border-medium)]';
                const flexClass = isSelf ? 'justify-end' : 'justify-start';
                const senderName = isSelf ? 'YOU' : `${data.senderId} (${data.role})`;
                const nameColor = isSelf ? 'text-sky-300' : 'text-amber-400';

                const msgHTML = `
                    <div class="flex ${flexClass} w-full">
                        <div class="max-w-[80%] border border-[var(--border-subtle)] rounded-xl p-3.5 ${alignClass}">
                            <div class="text-[0.65rem] font-bold mb-1 opacity-90 flex justify-between gap-6">
                                <span class="${nameColor} font-mono">${senderName}</span>
                                <span class="text-slate-400 font-mono">${data.timestamp}</span>
                            </div>
                            <div class="text-[0.9rem] text-white font-medium leading-relaxed">${data.message}</div>
                        </div>
                    </div>
                `;
                chatBox.insertAdjacentHTML('beforeend', msgHTML);
                chatBox.scrollTop = chatBox.scrollHeight;
            }
        }

        // Boot System
        window.addEventListener('DOMContentLoaded', () => {
            window.zeronetApp = new ZeroNetApp();
        });

        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('./sw.js')
                    .then(reg => console.log('Service Worker registered', reg))
                    .catch(err => console.error('Service Worker registration failed', err));
            });
        }
    
