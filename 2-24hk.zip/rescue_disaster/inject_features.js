const fs = require('fs');
const file = 'frontend/index.html';
let html = fs.readFileSync(file, 'utf8');

// 1. Inject Nav Button
const navTarget = '<button class="nav-item role-admin role-user" data-target="workspace-comms">';
const newNav = `
            <button class="nav-item role-admin role-user" data-target="workspace-dispatch">
                <i class="fas fa-truck-medical text-lg mb-1"></i>
                <span class="text-[0.6rem] font-bold tracking-wider">DISPATCH</span>
            </button>
            <button class="nav-item role-admin role-user" data-target="workspace-comms">`;
html = html.replace(navTarget, newNav);

// 2. Inject Section HTML
const sectionTarget = '<!-- MODULE 5: SECURE COMMS (USER/ADMIN) -->';
const newSection = `
            <!-- MODULE 6: RESOURCE DISPATCH & ZONES -->
            <section id="workspace-dispatch" class="h-full flex-col hidden">
                <div class="module-header flex justify-between items-center">
                    <span>MODULE 06: DISPATCH & ZONE PRIORITIZATION</span>
                    <button class="px-2 py-1 bg-slate-800 text-[0.6rem] text-slate-300 rounded border border-slate-600 hover:bg-slate-700" onclick="window.zeronetApp.resources.autoAllocate()">AUTO-ALLOCATE RESOURCES</button>
                </div>
                <div class="flex-grow flex gap-4 mt-4 overflow-hidden">
                    <!-- Left: Zones -->
                    <div class="w-1/2 flex flex-col gap-4 overflow-y-auto pr-2 pb-10">
                        <div class="bg-[var(--bg-card)] border border-[var(--border-medium)] rounded-xl p-4 shadow-sm">
                            <h3 class="text-xs uppercase font-bold text-slate-400 mb-3 border-b border-slate-800 pb-2"><i class="fas fa-map-location-dot mr-2"></i>PRIORITY ZONES</h3>
                            <div id="dispatch-zones-list" class="flex flex-col gap-3"></div>
                        </div>
                    </div>
                    <!-- Right: Resources -->
                    <div class="w-1/2 flex flex-col gap-4 overflow-y-auto pr-2 pb-10">
                        <div class="bg-[var(--bg-card)] border border-[var(--border-medium)] rounded-xl p-4 shadow-sm">
                            <h3 class="text-xs uppercase font-bold text-slate-400 mb-3 border-b border-slate-800 pb-2 flex justify-between">
                                <span><i class="fas fa-box-open mr-2"></i>INVENTORY & ALLOCATIONS</span>
                                <span class="text-[0.6rem] text-emerald-400 cursor-pointer" onclick="window.zeronetApp.resources.addDemoInventory()">+ SEED INVENTORY</span>
                            </h3>
                            <div id="dispatch-resources-list" class="flex flex-col gap-3"></div>
                        </div>
                    </div>
                </div>
            </section>
            
            <!-- MODULE 5: SECURE COMMS (USER/ADMIN) -->`;
html = html.replace(sectionTarget, newSection);

// 3. Inject JS Class & Logic
const jsTarget = 'class TacticalMap {';
const newJs = `
        class ResourceEngine {
            constructor(app) {
                this.app = app;
                this.zones = {};
                this.resources = {};
                this.populations = {};
                this.allocations = {};
            }

            render() {
                const zList = document.getElementById('dispatch-zones-list');
                const rList = document.getElementById('dispatch-resources-list');
                if (!zList || !rList) return;

                // Render Zones
                let zHtml = '';
                const sortedZones = Object.values(this.zones).sort((a,b) => b.score - a.score);
                if (sortedZones.length === 0) {
                    zHtml = '<div class="text-xs text-slate-500 italic p-3 text-center">No active disaster zones found. Run Nowcast simulation to generate zones.</div>';
                } else {
                    sortedZones.forEach(z => {
                        const scoreColor = z.score > 75 ? 'text-red-500' : (z.score > 50 ? 'text-amber-500' : 'text-emerald-500');
                        let popStr = '<span class="text-slate-500">No pop data</span>';
                        let vuln = Object.values(this.populations).find(p => p.zone_id === z.id);
                        if (vuln) {
                            popStr = '<i class="fas fa-users mr-1"></i> ' + vuln.count + ' (Med Needs: ' + vuln.medical_needs + ')';
                        }
                        zHtml += \`
                            <div class="p-3 bg-slate-900 rounded-lg border border-slate-700">
                                <div class="flex justify-between items-center mb-1">
                                    <span class="font-bold text-sm text-slate-200">\${z.name}</span>
                                    <span class="font-bold \${scoreColor} text-lg">\${z.score}</span>
                                </div>
                                <div class="text-[0.65rem] text-slate-400 mb-2 flex justify-between">
                                    <span>Hazard: \${z.hazard_severity}/100</span>
                                    <span>\${popStr}</span>
                                </div>
                                <button onclick="window.zeronetApp.map.calculateTacticalRoute(\${z.lat}, \${z.lng})" class="w-full text-center p-1 bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 rounded border border-slate-600 transition">PLOT ZONE ON MAP</button>
                            </div>
                        \`;
                    });
                }
                zList.innerHTML = zHtml;

                // Render Resources & Allocations
                let rHtml = '';
                const resArr = Object.values(this.resources);
                if (resArr.length === 0) {
                    rHtml = '<div class="text-xs text-slate-500 italic p-3 text-center">Inventory empty. Click seed inventory.</div>';
                } else {
                    resArr.forEach(r => {
                        let badge = 'bg-emerald-900/50 text-emerald-400 border-emerald-700';
                        if (r.status === 'DISPATCHED') badge = 'bg-amber-900/50 text-amber-400 border-amber-700';
                        if (r.status === 'OUT_OF_SERVICE') badge = 'bg-red-900/50 text-red-400 border-red-700';
                        rHtml += \`
                            <div class="p-3 bg-slate-900 rounded-lg border border-slate-700 flex justify-between items-center">
                                <div>
                                    <div class="font-bold text-xs text-slate-200">\${r.type} <span class="font-mono text-slate-500 ml-1">#\${r.id.substring(0,4)}</span></div>
                                    <div class="text-[0.6rem] text-slate-400 mt-0.5">Capacity: \${r.capacity}</div>
                                </div>
                                <div class="px-2 py-0.5 border text-[0.6rem] rounded font-bold \${badge}">\${r.status}</div>
                            </div>
                        \`;
                    });
                }
                rList.innerHTML = rHtml;
            }

            addDemoInventory() {
                const types = ['Ambulance', 'Rescue Boat', 'Medical Kit', 'Evacuation Bus', 'Helicopter'];
                for(let i=0; i<8; i++) {
                    const r = {
                        id: 'RES-' + Math.random().toString(36).substring(2,8).toUpperCase(),
                        type: types[Math.floor(Math.random() * types.length)],
                        capacity: Math.floor(Math.random() * 20) + 1,
                        status: 'AVAILABLE',
                        lat: this.app.gps.lat + (Math.random()*0.1 - 0.05),
                        lng: this.app.gps.lng + (Math.random()*0.1 - 0.05)
                    };
                    this.app.serverNet.emit('update_resource', r);
                }
                this.app.ui.logTerminal('DISPATCH', 'Seeded demo inventory of 8 assets.', 'log-tx');
            }

            autoAllocate() {
                if (Object.keys(this.zones).length === 0) {
                    alert("No zones identified. Run Nowcast simulation first to generate hazard zones.");
                    return;
                }
                const availRes = Object.values(this.resources).filter(r => r.status === 'AVAILABLE');
                if (availRes.length === 0) {
                    alert("No resources available for allocation. Seed inventory first.");
                    return;
                }
                
                const topZone = Object.values(this.zones).sort((a,b) => b.score - a.score)[0];
                const res = availRes[0]; // Assign first available to top zone
                
                const alloc = {
                    id: 'ALLOC-' + Math.random().toString(36).substring(2,8).toUpperCase(),
                    zone_id: topZone.id,
                    resource_id: res.id,
                    status: 'DISPATCHED'
                };
                res.status = 'DISPATCHED'; // local optimisic update
                
                this.app.serverNet.emit('allocate_resource', alloc);
                this.app.ui.logTerminal('DISPATCH', \`Auto-allocated \${res.type} to \${topZone.name} (Score: \${topZone.score})\`, 'log-tx');
                this.render();
            }

            createZoneFromNowcast(nc) {
                const id = 'ZONE-' + Math.random().toString(36).substring(2,8).toUpperCase();
                
                // Base score 0-100 logic
                let baseScore = Math.max(nc.multiTaskScores.cloudburstProb, nc.multiTaskScores.flashFloodHazard, nc.multiTaskScores.thunderstormRisk);
                
                const popCount = Math.floor(Math.random() * 1000) + 100;
                
                // Add pop modifier (+0 to +20)
                const popMod = Math.min(20, (popCount / 1000) * 20);
                
                const z = {
                    id: id,
                    name: nc.locationName + ' Priority Zone',
                    lat: nc.lat,
                    lng: nc.lng,
                    radius: 3000,
                    hazard_severity: baseScore,
                    exposure: popCount,
                    score: Math.min(100, Math.round(baseScore + popMod)),
                    status: 'ACTIVE'
                };
                
                this.app.serverNet.emit('update_zone', z);
                
                const p = {
                    id: 'POP-' + Math.random().toString(36).substring(2,8).toUpperCase(),
                    zone_id: id,
                    count: popCount,
                    medical_needs: Math.floor(popCount * 0.15) + ' high risk',
                    description: 'Simulated census data injection'
                };
                this.app.serverNet.emit('import_population', p);
                
                this.app.ui.logTerminal('DISPATCH', \`Created Priority Zone: \${z.name} [Score: \${z.score}/100]\`, 'log-rx');
            }
        }

        class TacticalMap {`;
html = html.replace(jsTarget, newJs);

// 4. Hook up to initial sync in constructor
const constructorSyncTarget = "this.db.records = data.patients || [];";
const newConstructorSync = `
                    this.db.records = data.patients || [];
                    if (data.zones) data.zones.forEach(z => this.resources.zones[z.id] = z);
                    if (data.resources) data.resources.forEach(r => this.resources.resources[r.id] = r);
                    if (data.vulnerable) data.vulnerable.forEach(p => this.resources.populations[p.id] = p);
                    if (data.allocations) data.allocations.forEach(a => this.resources.allocations[a.id] = a);
                    this.resources.render();
`;
html = html.replace(constructorSyncTarget, newConstructorSync);

// 5. Hook up new relays
const relayTarget = "this.serverNet.on('mesh_relay', (packetStr) => {";
const newRelay = `
                this.serverNet.on('zone_relay', (z) => {
                    this.resources.zones[z.id] = z;
                    this.resources.render();
                });
                this.serverNet.on('resource_relay', (r) => {
                    this.resources.resources[r.id] = r;
                    this.resources.render();
                });
                this.serverNet.on('population_relay', (p) => {
                    this.resources.populations[p.id] = p;
                    this.resources.render();
                });
                this.serverNet.on('allocation_relay', (a) => {
                    this.resources.allocations[a.id] = a;
                    this.resources.render();
                });
                
                this.serverNet.on('mesh_relay', (packetStr) => {`;
html = html.replace(relayTarget, newRelay);

// 6. Hook up Nowcast trigger
const nowcastTriggerTarget = "this.app.ui.logTerminal('NOWCAST', `Hazard analysis compiled for ${res.locationName}.`, 'log-rx');";
const newNowcastTrigger = `
                        this.app.ui.logTerminal('NOWCAST', \`Hazard analysis compiled for \${res.locationName}.\`, 'log-rx');
                        this.app.resources.createZoneFromNowcast(res);
`;
html = html.replace(nowcastTriggerTarget, newNowcastTrigger);

// 7. Initialize in ZeroNetApp constructor
const appInitTarget = "this.nowcast = new NowcastEngine(this);";
const newAppInit = `
                this.nowcast = new NowcastEngine(this);
                this.resources = new ResourceEngine(this);
`;
html = html.replace(appInitTarget, newAppInit);

fs.writeFileSync(file, html);
console.log('Features injected successfully');
